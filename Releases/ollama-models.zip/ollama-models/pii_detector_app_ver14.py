import json
import re
import os
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import requests
import PySimpleGUI as sg

import parent_notifier

FONT_NORMAL = ("Meiryo", 11)
FONT_LOG = ("Meiryo", 11)
FONT_HEADER = ("Meiryo", 13, "bold")

RISK_COLORS = {
    "critical": ("#FFFFFF", "#A94442"),
    "high": ("#FFFFFF", "#D9534F"),
    "medium": ("#000000", "#F0AD4E"),
    "low": ("#000000", "#F5F5F5"),
}
RISK_LABELS = {"critical": "危険", "high": "高", "medium": "中", "low": "低"}
RISK_ORDER = {"critical": 0, "high": 1, "medium": 2, "low": 3}

CONFIG_PATH = Path.home() / ".pii_detector_config.json"

DEFAULT_CONFIG = {
    "parent_email": "",
    "smtp_server": "smtp.gmail.com",
    "smtp_port": 587,
    "ollama_model": "elyza-jp",
    "ollama_url": "http://localhost:11434/api/generate",
    "max_workers": 3,
}


def load_config():
    if CONFIG_PATH.exists():
        with open(CONFIG_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        merged = DEFAULT_CONFIG.copy()
        merged.update(data)
        return merged
    return DEFAULT_CONFIG.copy()


def save_config(config: dict):
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(config, f, ensure_ascii=False, indent=2)


HISTORY_PATH = Path.home() / ".pii_detector_history.jsonl"
MAX_HISTORY_DISPLAY = 50


def save_history_record(source_file: str, results: list, aggregate_report):
    """検査結果1回分を履歴ファイルに1行(JSON)追記する"""
    from datetime import datetime

    counts = {"critical": 0, "high": 0, "medium": 0, "low": 0}
    for r in results:
        counts[r["risk"]] = counts.get(r["risk"], 0) + 1
    notified_n = sum(1 for r in results if r.get("notified") == "送信済み")

    record = {
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "source_file": source_file,
        "total": len(results),
        "counts": counts,
        "notified": notified_n,
        "results": results,
        "aggregate": aggregate_report,
    }
    try:
        with open(HISTORY_PATH, "a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")
    except Exception:
        pass
    return record


def load_history_records():
    """履歴ファイルを読み込み、新しい順のリストで返す"""
    if not HISTORY_PATH.exists():
        return []
    records = []
    try:
        with open(HISTORY_PATH, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    records.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
    except Exception:
        return []
    records.reverse()
    return records


VALID_RISK_LEVELS = ("critical", "high", "medium", "low")
RISK_DOWNGRADE_ORDER = ("critical", "high", "medium", "low")


def _has_phone_like_pattern(text: str) -> bool:
    """
    本文にハイフン区切りの電話番号、または9〜11桁の連続した数字があるかを確認する。
    末尾の区切りを3〜4桁に限定することで、"2026-05-08"のような日付表記を
    電話番号と誤認しないようにしている(日付の末尾は日にちなので通常2桁)。
    """
    if re.search(r"\d{2,4}[-‐―ー]\d{2,4}[-‐―ー]\d{3,4}(?!\d)", text):
        return True
    if re.search(r"(?<!\d)\d{9,11}(?!\d)", text):
        return True
    return False


def _has_email_like_pattern(text: str) -> bool:
    """本文に xxx@xxx.xxx 形式のメールアドレスらしき文字列があるかを確認する"""
    return bool(re.search(r"[\w.\-]+@[\w.\-]+\.\w+", text))


SELF_NAME_MARKERS = re.compile(
    r"(私の?名前は|本名は|呼び名は|って呼んでください|と呼んでください|といいます|と申します|というものです)"
)

SELF_INTRO_MENTION = re.compile(r"^\s*@[A-Za-z0-9_]+(です|だよ|ですー|だよー|なのです|と言います|といいます)")


def _has_grounded_self_identification(text: str) -> bool:
    """
    「本人特定性」を裏付ける、機械的に確認できる根拠が本文にあるかどうかを判定する。
    (電話番号 / メールアドレス / 明示的な自己紹介の表現 / @ハンドルでの自己紹介)
    これらが1つも無ければ、「本人特定性」の主張には根拠がないと判断する。
    """
    return bool(
        _has_phone_like_pattern(text)
        or _has_email_like_pattern(text)
        or SELF_NAME_MARKERS.search(text)
        or SELF_INTRO_MENTION.match(text)
    )


LEADING_REPLY_MENTION = re.compile(r"^\s*@[A-Za-z0-9_]+\s")

BOILERPLATE_SNIPPETS = (
    "本名や、投稿者本人が明示的に名乗っている呼び名が判明している。",
    "「所属」と「最寄り駅/居住地域」の両方が同時に確定している。",
    "「所属」または「生活拠点」のどちらか一方が確定しており、かつ詳細な行動パターン",
    "単体の属性(学年、都道府県レベルの広域住所、趣味など)のみが判明している。",
)

QUOTE_PATTERN = re.compile(r"「(.+?)」")


def _downgrade_risk(risk: str) -> str:
    """リスクレベルを1段階だけ安全側(低い方)に引き下げる"""
    idx = RISK_DOWNGRADE_ORDER.index(risk) if risk in RISK_DOWNGRADE_ORDER else 3
    return RISK_DOWNGRADE_ORDER[min(idx + 1, 3)]


def _format_category_str(categories) -> str:
    return "、".join(categories) if categories else "-"


def _build_natural_reason(original_reason: str, notes: list, final_risk_label: str, final_category: str) -> str:
    """
    「[1]元の判定 [2]補正内容 [3]最終判定」という3段階の生データ表示ではなく、
    ユーザーが一読して「結局どう評価されたのか」がすぐ分かる、1つの自然な文章にまとめる。
    """
    if not notes:
        return original_reason

    notes_text = "。".join(n.rstrip("。") for n in notes)
    original_clean = (original_reason or "").rstrip("。")

    if original_clean:
        return (
            f"{original_clean}と判定されましたが、{notes_text}。"
            f"そのため、最終的な評価は「{final_risk_label}」(カテゴリ: {final_category})です。"
        )
    return f"{notes_text}。最終的な評価は「{final_risk_label}」(カテゴリ: {final_category})です。"


def sanity_check_llm_result(text: str, parsed: dict) -> dict:
    """LLMの判定結果を本文と照合し、事実に基づかない主張を補正する(過大評価は引き下げ、過小評価は引き上げ)。"""
    reason = parsed.get("reason") or ""
    combined_text = reason + " " + " ".join(parsed.get("extracted_details") or [])
    original_risk = parsed.get("risk", "low")
    categories = parsed.get("matched_categories") or []

    only_honnin = categories == ["本人特定性"]
    if only_honnin and original_risk != "low" and not _has_grounded_self_identification(text):
        forced_note = (
            "「本人特定性」以外に該当する評価軸が無く、"
            "かつ本文に電話番号・メールアドレス・明示的な自己紹介のいずれの根拠も"
            "見つからなかったため、根拠のない判定とみなしlowに確定しました。"
        )
        parsed["risk"] = "low"
        parsed["matched_categories"] = []
        parsed["extracted_details"] = []
        parsed["reason"] = _build_natural_reason(reason, [forced_note], RISK_LABELS["low"], "-")
        parsed["original_reason"] = reason
        parsed["correction_notes"] = [forced_note]
        parsed["correction_type"] = "forced_low"
        return parsed

    downgrade_notes = []
    upgrade_notes = []

    needs_upgrade = False
    if original_risk != "critical":
        if _has_phone_like_pattern(text):
            needs_upgrade = True
            upgrade_notes.append("本文に電話番号らしき文字列が実在するため、リスクをcritical(危険)に引き上げました")
        elif _has_email_like_pattern(text):
            needs_upgrade = True
            upgrade_notes.append("本文にメールアドレスらしき文字列が実在するため、リスクをcritical(危険)に引き上げました")

    if "電話番号" in combined_text and not _has_phone_like_pattern(text):
        parsed["extracted_details"] = [
            d for d in parsed.get("extracted_details", []) if "電話番号" not in d
        ]
        downgrade_notes.append("本文に電話番号らしき数字列が見つからなかったため、電話番号の判定を取り消しました")

    if ("メールアドレス" in combined_text or "メアド" in combined_text) and not _has_email_like_pattern(text):
        parsed["extracted_details"] = [
            d for d in parsed.get("extracted_details", []) if ("メールアドレス" not in d and "メアド" not in d)
        ]
        downgrade_notes.append("本文にメールアドレスらしき文字列が見つからなかったため、メールアドレスの判定を取り消しました")

    if "本人特定性" in categories and not _has_grounded_self_identification(text):
        parsed["extracted_details"] = [
            d for d in parsed.get("extracted_details", []) if ("呼び名" not in d and "名前" not in d)
        ]
        parsed["matched_categories"] = [
            c for c in parsed.get("matched_categories", []) if c != "本人特定性"
        ]
        if LEADING_REPLY_MENTION.match(text):
            downgrade_notes.append(
                "投稿冒頭の「@」はXの慣習上、返信先(他人)のIDである可能性が高く、"
                "本文中に自己紹介の表現も見当たらないため、本人特定性の判定(カテゴリ・抽出内容とも)を取り消しました"
            )
        else:
            downgrade_notes.append(
                "本文中に投稿者本人が明示的に名乗っている表現が見当たらず、"
                "文中の名前は第三者(言及されている相手)を指している可能性が高いため、"
                "本人特定性の判定(カテゴリ・抽出内容とも)を取り消しました"
            )

    if any(snippet in reason for snippet in BOILERPLATE_SNIPPETS):
        downgrade_notes.append(
            "判定理由が評価基準の文章とほぼ同一で、この投稿固有の根拠に基づく判断か確認できないため、"
            "念のためリスクを引き下げました(目視確認を推奨します)"
        )

    quotes = QUOTE_PATTERN.findall(reason)
    if quotes and not any(q in text for q in quotes):
        downgrade_notes.append(
            "判定理由で引用されている内容が本文中に見つからず、実在しない内容を根拠にしている疑いがあるため、"
            "念のためリスクを引き下げました(目視確認を推奨します)"
        )

    if needs_upgrade:
        parsed["risk"] = "critical"
        all_notes = upgrade_notes + downgrade_notes
        parsed["reason"] = _build_natural_reason(
            reason, all_notes, RISK_LABELS["critical"], _format_category_str(parsed.get("matched_categories"))
        )
        parsed["original_reason"] = reason
        parsed["correction_notes"] = all_notes
        parsed["correction_type"] = "upgrade"
    elif downgrade_notes:
        parsed["risk"] = _downgrade_risk(original_risk)
        parsed["reason"] = _build_natural_reason(
            reason, downgrade_notes, RISK_LABELS[parsed["risk"]], _format_category_str(parsed.get("matched_categories"))
        )
        parsed["original_reason"] = reason
        parsed["correction_notes"] = downgrade_notes
        parsed["correction_type"] = "downgrade"
    else:
        parsed["original_reason"] = reason
        parsed["correction_notes"] = []
        parsed["correction_type"] = None

    return parsed


def _post_to_ollama_with_retry(url: str, model: str, prompt: str, timeout: int = 120, max_retries: int = 2,
                                 seed: int = 42, num_predict: int = 512):
    """
    OllamaへのAPIリクエストを行う。タイムアウトや接続エラーが発生した場合、
    間隔を空けて自動的に再試行する(CPU推論は負荷や並列数によって
    応答が遅れることがあり、1回の失敗だけで諦めないようにするため)。
    最終的に失敗した場合は、最後に発生した例外をそのまま送出する。
    """
    import time as _time

    last_error = None
    for attempt in range(max_retries + 1):
        try:
            return requests.post(
                url,
                json={
                    "model": model,
                    "prompt": prompt,
                    "stream": False,
                    "format": "json",
                    "options": {
                        "temperature": 0,
                        "seed": seed,
                        "top_p": 1.0,
                        "top_k": 1,
                        "num_predict": num_predict,
                    },
                },
                timeout=timeout,
            )
        except (requests.exceptions.Timeout, requests.exceptions.ConnectionError) as e:
            last_error = e
            if attempt < max_retries:
                _time.sleep(2)
                continue
            raise last_error


def _call_ollama_and_get_json_text(url: str, model: str, prompt: str, timeout: int = 120,
                                     num_predict: int = 512, max_parse_retries: int = 1) -> str:
    """
    Ollamaを呼び出し、応答テキストを返す。応答にJSON({...})が
    1つも含まれていない(=解析エラーになる)場合は、乱数の種を変えて
    もう一度だけ問い合わせる(同じseedのまま再試行しても同じ結果に
    なりやすいため、必ずseedを変える)。
    """
    raw_output = ""
    for attempt in range(max_parse_retries + 1):
        res = _post_to_ollama_with_retry(
            url, model, prompt, timeout=timeout, seed=42 + attempt, num_predict=num_predict,
        )
        res.raise_for_status()
        raw_output = res.json().get("response", "").strip()
        if re.search(r"\{.*\}", raw_output, re.DOTALL):
            return raw_output
    return raw_output


MENTION_TOKEN_PATTERN = re.compile(r"(?<![\w.])@[A-Za-z0-9_]+")


def sanitize_mentions_for_llm(text: str) -> str:
    """
    LLMに渡す直前に、投稿本文から「返信先を示す@ハンドル名」を取り除く。

    これまでの安全弁は「LLMが誤って@ハンドルを本人の名前や電話番号と
    誤認した後に、事後的に補正する」方式だったが、そもそも紛らわしい
    文字列をLLMに見せなければ、この種のハルシネーションは根本的に発生しなくなる。

    ただし例外として、「@hinanoです」のようにスペース無しで直接
    自己紹介につながっている@ハンドルは、本人特定性の重要な情報のため
    削除せずに残す。それ以外の@ハンドル(返信先・引用元など、他人を指すもの)は
    すべて取り除く。

    メールアドレス(taro@example.com 等)の@は、直前が英数字やドットであるため
    このパターンにはマッチせず、誤って壊されることはない。
    """
    self_intro_match = SELF_INTRO_MENTION.match(text)
    if self_intro_match:
        protected_end = self_intro_match.end()
        protected_part = text[:protected_end]
        rest_part = text[protected_end:]
        rest_sanitized = MENTION_TOKEN_PATTERN.sub("", rest_part)
        return (protected_part + rest_sanitized).strip()

    return MENTION_TOKEN_PATTERN.sub("", text).strip()


def llm_check(text: str, config: dict):
    sanitized_text = sanitize_mentions_for_llm(text)
    prompt = f"""あなたはSNS投稿から個人(特に未成年者)を特定できてしまうリスクを評価する専門家です。
以下の4つの評価軸それぞれについて、投稿に該当する情報が含まれているかを確認してください。

【評価軸】
1. 本人特定性: 氏名、ニックネーム・呼び名、家族構成、具体的な年齢、誕生日、電話番号・メールアドレス・LINE ID等の直接連絡先
2. 生活拠点・行動圏: 最寄り駅、利用路線、頻繁に利用する店舗、市区町村名、局地的な気象情報(例:「今〇〇駅周辺だけ豪雨」)
3. 所属・社会的立場: 学校名、学部学科、会社名、特定のプロジェクト名、受講中の講義、所属サークル
4. 行動パターン: リアルタイムの移動・帰宅報告、定期的な生活リズム(通学時間、特定の曜日・時間のルーチン)、不在通知(「今から〇日間家にいません」等)

【判定時の重要な注意点(誤検知を防ぐため必ず守ること)】
- SNSの「@」から始まる文字列(例: @hinano, @user0123)は、リプライ先や引用元を示すユーザーID・ハンドルネームであり、本文中で投稿者本人が明示的に「私の名前(呼び名)は〇〇です」のように名乗っていない限り、本人特定性の「呼び名」とはみなさない。
- 「@」から始まる文字列に数字が含まれていても、それはユーザーIDの一部であり、電話番号とはみなさない。
- 電話番号(「090-1234-5678」のようにハイフンで区切られている、または「電話番号は」「連絡先は」「DMして」等の文脈を伴う数字列)、メールアドレス、LINE IDなどの「直接連絡が可能になる情報」は、生活拠点や所属ではなく必ず「本人特定性」に分類すること。
- 郵便番号は、「〒」マークまたは「郵便番号は」という明示的な表現を伴う数字列のみを対象とし、それ以外の数字列(ID、日付、時刻、電話番号など)は郵便番号として扱わない。郵便番号は「生活拠点・行動圏」に分類する。
- 投稿が「RT @〇〇:」のようにリツイート/引用の形式で始まっている場合、その引用部分は投稿者本人ではなく他人の発言である。他人の発言に含まれる情報は、投稿者本人を特定する情報としては扱わない。
- URLに含まれる文字列・数字列は、ランダムに生成された識別子であることが多いため、住所・電話番号・郵便番号としては扱わない。
- 「今日は暑い」「明日は雨らしい」のような一般的な天気の感想だけでは局地的気象情報とみなさない。特定の駅名・地域名と結びついている場合(例:「〇〇駅前だけ急に土砂降り」)のみ対象とする。
- 数字が含まれていても、それが年齢・学年であると明確に読み取れる文脈(「17歳です」「高校2年です」等)がない限り、日付・時刻・番号などを年齢や誕生日として扱わない。

【リスクレベルの判定手順(必ずこの順番で、上から順に確認すること)】
評価軸がいくつ該当したか(1つだけか、複数か)は、リスクレベルの判定には直接関係ありません。matched_categoriesに複数の軸を書くこと自体は、criticalの判定を妨げたり弱めたりしません。以下の手順で、該当した最初の段階のリスクレベルを採用してください。

ステップ1: 次のいずれか1つにでも当てはまれば、他にどんな評価軸が追加で該当していても関係なく critical(危険) とする。(1つでも当てはまった時点で判定終了。ステップ2以降は確認しない)
  (a) 本名、または投稿者本人が明示的に名乗っている呼び名が判明している
  (b) 電話番号・メールアドレス・LINE IDなど、直接連絡が可能になる情報が判明している
  (c) 「所属」と「最寄り駅/居住地域」の両方が同時に確定している
  → 例えば、氏名(呼び名)と学校名が両方判明している投稿は、(a)に該当するだけで既にcriticalであり、所属も一緒に判明しているからといってhighに弱めてはならない。同様に、メールアドレスと生活拠点の両方が判明している投稿も、(b)に該当するだけで既にcriticalである。

ステップ2: ステップ1のどれにも当てはまらず、次に当てはまれば high(高) とする。
  (a) 「所属」または「生活拠点」のどちらか一方が確定しており、かつ詳細な行動パターン(通学時間、特定の曜日・時間のルーチンなど)も判明している

ステップ3: ステップ1・2のどれにも当てはまらず、次のいずれかに当てはまれば medium(中) とする。
  (a) 単体の属性(学年、都道府県レベルの広域住所、趣味など)のみが判明している
  (b) 単体では個人を特定できないが、他の情報と組み合わさると特定に近づく状態

ステップ4: ステップ1〜3のどれにも当てはまらなければ low(低) とする。時事ネタ、趣味の感想、一般的な話題のみで、上記いずれの評価軸の手がかりも含まれない場合。SNSのID表記やリツイート、URLのみを理由にリスクを上げてはならない。

【判定例(参考)】
- 投稿「@0890110 了解です!」→ @から始まるIDへの返信であり、電話番号でも呼び名の名乗りでもない。他の手がかりがなければ low。
- 投稿「@hinanoです、よろしく」→ 投稿者本人が「@hinano」というハンドルネームを自分の呼び名として明示的に名乗っているため、本人特定性の「呼び名」に該当し、ステップ1(a)によりcritical。
- 投稿「RT @taro: 明日〇〇小学校で遠足です」→ taroという他人の発言であり、投稿者本人の所属情報としては扱わない(他に本人の発言がなければ low)。
- 投稿「新しい携帯にしたよ！番号変わったから知りたい人はDMしてね 090-1234-5678」→ 電話番号という直接連絡先が判明しているため、カテゴリは「本人特定性」、ステップ1(b)によりcritical(危険)。
- 投稿「私、〇〇小学校5年2組の山田です」→ 「山田」という氏名(呼び名)が明示的に判明しているため、ステップ1(a)によりcritical。所属(学校名)も同時に判明しているが、それによってhighに弱めてはならない。カテゴリは「本人特定性、所属・社会的立場」の両方を記載してよいが、リスクはcriticalのまま。
- 投稿「連絡先交換しよう！メアドは taro.yamada2010@example.com です」→ メールアドレスという直接連絡先が判明しているため、ステップ1(b)によりcritical。

投稿: 「{sanitized_text}」

必ず次のJSON形式のみで出力してください。説明文やJSON以外の文字は一切不要です。
matched_categoriesとextracted_detailsは、該当する評価軸がなければ両方とも空配列にしてください。
{{"risk": "critical、high、medium、lowのいずれか", "matched_categories": ["該当した評価軸の名前を日本語で。複数可、なければ空配列"], "extracted_details": ["投稿から実際に読み取れた具体的な固有名詞・数値を「評価軸名: 具体的な値」の形式で。例: '所属・社会的立場: 〇〇大学工学部', '本人特定性: 電話番号090-1234-5678'。抽象的な言い回しではなく、実際にテキストに書かれている固有名詞や数値をそのまま書き出すこと"], "reason": "この判定に至った理由を簡潔に"}}
"""
    try:
        raw_output = _call_ollama_and_get_json_text(
            config["ollama_url"], config["ollama_model"], prompt, timeout=120, num_predict=512, max_parse_retries=1,
        )

        match = re.search(r"\{.*\}", raw_output, re.DOTALL)
        if not match:
            return {"risk": "low", "matched_categories": [], "extracted_details": [], "reason": "LLM出力の解析に失敗"}
        parsed = json.loads(match.group(0))

        if parsed.get("risk") not in VALID_RISK_LEVELS:
            parsed["risk"] = "low"
        if "matched_categories" not in parsed or not isinstance(parsed["matched_categories"], list):
            parsed["matched_categories"] = []
        if "extracted_details" not in parsed or not isinstance(parsed["extracted_details"], list):
            parsed["extracted_details"] = []

        parsed = sanity_check_llm_result(text, parsed)

        return parsed
    except requests.exceptions.HTTPError as e:
        if e.response is not None and e.response.status_code == 404:
            return {
                "risk": "low", "matched_categories": [], "extracted_details": [],
                "reason": (
                    f"LLM呼び出しエラー(404): モデル「{config.get('ollama_model')}」が見つかりません。"
                    "`ollama list` で名前が完全に一致しているか確認してください"
                    "(設定タブのモデル名欄に余分な空白が入っていないかもご確認ください)。"
                ),
            }
        return {"risk": "low", "matched_categories": [], "extracted_details": [], "reason": f"LLM呼び出しエラー: {e}"}
    except requests.exceptions.Timeout as e:
        return {
            "risk": "low", "matched_categories": [], "extracted_details": [],
            "reason": (
                f"[判定未完了・要再確認] LLMからの応答がタイムアウトしました({e})。"
                "この投稿は実際には判定されていません(低リスクという意味ではありません)。"
                "設定タブの並列処理数を減らすか、時間を置いて再検査することをお勧めします。"
            ),
        }
    except requests.exceptions.ConnectionError as e:
        return {
            "risk": "low", "matched_categories": [], "extracted_details": [],
            "reason": (
                f"[判定未完了・要再確認] Ollamaに接続できませんでした({e})。"
                "Ollamaが起動しているか確認してください(`ollama serve`、または`ollama run モデル名`)。"
                "この投稿は実際には判定されていません(低リスクという意味ではありません)。"
            ),
        }
    except Exception as e:
        return {"risk": "low", "matched_categories": [], "extracted_details": [], "reason": f"LLM呼び出しエラー: {e}"}


def build_category_groups(results):
    """critical/high/medium の投稿を対象に、評価軸(カテゴリ)ごとにグルーピングする"""
    target = [r for r in results if r["risk"] in ("critical", "high", "medium")]

    groups = {}
    for r in target:
        cats = [c.strip() for c in r["category"].split("、") if c.strip() and c.strip() != "-"]
        if not cats:
            cats = ["分類不明"]
        for c in cats:
            g = groups.setdefault(c, {"indices": [], "reasons": [], "details": [], "dates": {}})
            g["indices"].append(r["index"])
            if r["reason"] and r["reason"] not in g["reasons"]:
                g["reasons"].append(r["reason"])
            for d in r.get("details", []):
                if d and d not in g["details"]:
                    g["details"].append(d)
            if r.get("date"):
                g["dates"][r["index"]] = r["date"]
    return groups


def format_category_groups_for_prompt(groups):
    """カテゴリごとのグループを、LLMに渡すための短い箇条書きに要約する(投稿日時も併記する)"""
    lines = []
    for i, (cat, info) in enumerate(groups.items(), start=1):
        shown_indices = info["indices"][:10]
        indices_str = "、".join(
            f"投稿{idx}({info['dates'][idx]})" if idx in info["dates"] else f"投稿{idx}"
            for idx in shown_indices
        )
        if len(info["indices"]) > 10:
            indices_str += f" 他{len(info['indices']) - 10}件"
        reasons_str = " / ".join(info["reasons"][:3]) if info["reasons"] else "詳細理由なし"
        details_str = " / ".join(info["details"][:5]) if info["details"] else "(具体的な値は抽出されず)"
        lines.append(
            f"{i}. [{cat}] 該当投稿: {len(info['indices'])}件 ({indices_str})\n"
            f"   理由の例: {reasons_str}\n"
            f"   実際に読み取れた内容: {details_str}"
        )
    return "\n".join(lines)


def llm_aggregate_profile(results, config):
    """
    全投稿の判定結果(critical/high/medium)をカテゴリごとに要約し、
    それらを組み合わせるとこの人物についてどこまで特定できてしまうかを
    LLMに1回だけ問い合わせて推論させる。

    対象になる投稿が1件もない場合は None を返す。
    """
    groups = build_category_groups(results)
    if not groups:
        return None

    summary_text = format_category_groups_for_prompt(groups)

    prompt = f"""以下は、あるSNSアカウントの投稿群から個別に検出された
「個人特定につながる可能性のある情報」を、評価軸ごとに集約した一覧です。
これらを組み合わせることで、この人物についてどこまで特定できてしまうかを推論してください。

【検出済み情報の集約一覧】
{summary_text}

【評価軸の意味】
1. 本人特定性: 氏名、呼び名、家族構成、年齢、誕生日、電話番号・メールアドレス等の直接連絡先
2. 生活拠点・行動圏: 最寄り駅、路線、近隣店舗、市区町村、局地気象
3. 所属・社会的立場: 学校、会社、サークル、特定の業務・講義名
4. 行動パターン: リアルタイムの移動・帰宅報告、定期的な生活リズム、不在通知

【総合リスク判定基準】
- critical(危険): 本名・呼び名・直接連絡先(電話番号等)が判明している。または「所属」と「生活拠点」が両方確定している。
- high(高): 所属か生活拠点のどちらか一方が確定しており、かつ詳細な行動パターンも判明している。
- medium(中): 単体属性のみ判明、または組み合わせで特定に近づく一歩手前。
- low(低): 特定につながる手がかりが乏しい。

【inferred_profileを書く際の必須ルール】
- 「氏名が判明」「所属が確定」のような抽象的な言い回しだけで終わらせず、上の集約一覧に含まれる「実際に読み取れた内容」の固有名詞・数値(具体的な呼び名、学校名、駅名、電話番号など)を、そのまま文章に含めること。
- 集約一覧の「所属・社会的立場」に含まれる情報から、この人物の属性(小学生・中学生・高校生・大学生・社会人など)を可能な範囲で推測し、明記すること。判断材料が不十分な場合は「学生である可能性が高い」のように推測の度合いが分かる書き方をする。
- 集約一覧に無い情報を勝手に創作しないこと。あくまで一覧に含まれる情報のみを根拠にする。特に、卒業・就職・受験結果などのライフイベントは、集約一覧に明確な記述がある場合のみ言及し、推測でストーリーを作り出さないこと。
- 【重要】「実際に読み取れた内容は〜」「該当投稿は〜件」のような、上の集約一覧の見出し語や書式をそのまま文章に転用しないこと。あくまで人間が読んで自然な説明文(例:「〇〇大学に在籍し、ITパスポートを保有していることが投稿から読み取れます」)として書くこと。ある評価軸に該当する情報が無かった場合は、その軸について触れなくてよい(「本人特定性は無し」のように、無かったことをわざわざ書く必要は無い)。

【★矛盾する情報の扱い(最重要)★】
各投稿には日付が付与されている場合があります(例:「投稿5(2026-04-10)」)。同じ人物についての情報でも、投稿の時期によって内容が変化している(例: 古い投稿では「高校生」、新しい投稿では「大学生」)ことがあります。この場合、絶対に守ること:
- 「高校生であり、かつ大学生である」のように矛盾する属性を1つの文章の中で同時に断定してはならない。
- 日付が分かる場合は、最も新しい日付の投稿を「現在の状況」として優先して採用し、古い日付の投稿の内容は「以前は〜だった可能性がある」のように、時期を区別して書くこと。
- 日付が不明で、かつ矛盾する情報がある場合は、どちらか一方に断定せず「時期によって状況が異なる可能性がある」と留保すること。
- 所属先(学校名・会社名など)についても、複数の異なる所属先が検出された場合は、同一時点に両方に所属しているかのように書かず、時期の違いとして扱うこと。

必ず次のJSON形式のみで出力してください。説明文やJSON以外の文字は不要です。
{{"overall_risk": "critical/high/medium/lowのいずれか", "inferred_profile": "この人物について推定できてしまう具体的な情報(固有名詞を含む)と、属性の推測を200〜300字程度の自然な文章でまとめる", "key_combination": "特にリスクを引き上げた情報の組み合わせを、具体的な固有名詞を用いて簡潔に説明(なければ空文字)"}}
"""
    try:
        raw_output = _call_ollama_and_get_json_text(
            config["ollama_url"], config["ollama_model"], prompt,
            timeout=90, num_predict=800, max_parse_retries=2,
        )

        match = re.search(r"\{.*\}", raw_output, re.DOTALL)
        if not match:
            return {
                "overall_risk": "medium",
                "inferred_profile": "総合レポートの生成に失敗しました(LLM出力の解析エラー)。",
                "key_combination": "",
            }
        parsed = json.loads(match.group(0))
        if parsed.get("overall_risk") not in VALID_RISK_LEVELS:
            parsed["overall_risk"] = "medium"
        parsed.setdefault("inferred_profile", "")
        parsed.setdefault("key_combination", "")
        return parsed
    except Exception as e:
        return {
            "overall_risk": "medium",
            "inferred_profile": f"総合レポートの生成中にエラーが発生しました: {e}",
            "key_combination": "",
        }


def _extract_json_text(raw: str) -> str:
    """
    Xの公式アーカイブに含まれる tweets.js は、
      window.YTD.tweets.part0 = [ {...}, {...} ]
    のように、先頭に "変数名 = " というJavaScriptの代入文が付いている。
    純粋なJSONとして読めるように、この前置き部分を取り除く。
    """
    raw = raw.strip()

    if raw.startswith("[") or raw.startswith("{"):
        return raw

    match = re.search(r"=\s*(\[.*\]|\{.*\})\s*;?\s*$", raw, re.DOTALL)
    if match:
        return match.group(1)

    idx = min(
        [i for i in (raw.find("["), raw.find("{")) if i != -1],
        default=-1,
    )
    if idx != -1:
        return raw[idx:]

    raise ValueError("JS/JSONファイルからデータ部分を抽出できませんでした")


def parse_twitter_date(raw_date: str):
    """
    Xのエクスポートに含まれる日付文字列(例: "Mon Sep 01 08:00:00 +0000 2026")を
    "2026-09-01" のような読みやすい形式に変換する。解析に失敗した場合は空文字を返す。
    """
    if not raw_date:
        return ""
    try:
        from datetime import datetime
        dt = datetime.strptime(raw_date, "%a %b %d %H:%M:%S %z %Y")
        return dt.strftime("%Y-%m-%d")
    except Exception:
        return ""


def build_tweet_url(post_id: str) -> str:
    """
    投稿ID(id_str)から、投稿ページへのURLを組み立てる。
    Xのエクスポートデータには投稿者自身のユーザー名が含まれていないため、
    ユーザー名の代わりに "i" を使う形式(https://x.com/i/web/status/ID)を用いる。
    この形式でも正しい投稿ページにリダイレクトされる。
    """
    if not post_id:
        return ""
    return f"https://x.com/i/web/status/{post_id}"


def load_posts_from_json(path: str):
    with open(path, "r", encoding="utf-8") as f:
        raw = f.read()

    json_text = _extract_json_text(raw)
    data = json.loads(json_text)

    posts = []
    if isinstance(data, list):
        for item in data:
            if isinstance(item, dict) and "tweet" in item:
                text = item["tweet"].get("full_text") or item["tweet"].get("text", "")
                date = parse_twitter_date(item["tweet"].get("created_at", ""))
                post_id = item["tweet"].get("id_str") or item["tweet"].get("id", "")
                if text:
                    posts.append({"text": text, "date": date, "url": build_tweet_url(post_id)})
            elif isinstance(item, dict) and "full_text" in item:
                date = parse_twitter_date(item.get("created_at", ""))
                post_id = item.get("id_str") or item.get("id", "")
                if item["full_text"]:
                    posts.append({"text": item["full_text"], "date": date, "url": build_tweet_url(post_id)})
            elif isinstance(item, str):
                if item:
                    posts.append({"text": item, "date": "", "url": ""})
    return posts


RT_PATTERN = re.compile(r"^\s*RT\s*@[A-Za-z0-9_]+\s*[:：]")


def is_retweet(text: str) -> bool:
    return bool(RT_PATTERN.match(text))


def run_pipeline_background(json_path: str, config: dict, window: sg.Window, parent_password: str = ""):
    """
    重い処理(ファイル読み込み・正規表現・LLM問い合わせ・通知)を
    メインのGUIスレッドとは別のスレッドで実行する関数。
    進捗は window.write_event_value() を使ってメインループへスレッドセーフに通知する。
    """
    try:
        posts = load_posts_from_json(json_path)
    except Exception as e:
        window.write_event_value("-ERROR-", f"ファイル読み込みエラー: {e}")
        return

    total = len(posts)
    if total == 0:
        window.write_event_value("-ERROR-", "投稿データが1件も見つかりませんでした")
        return

    window.write_event_value("-LOG-", f"投稿数: {total}件を読み込みました")

    results = [None] * total

    window.write_event_value(
        "-LOG-",
        f"全{total}件をローカルLLMで並列判定します(並列数: {config.get('max_workers', 3)})",
    )
    window.write_event_value("-PROGRESS-", (0, total))

    done_count = 0
    max_workers = max(1, int(config.get("max_workers", 3)))

    llm_target_indices = []
    for i, post in enumerate(posts):
        if is_retweet(post["text"]):
            rt_reason = "RT(リツイート)のため評価対象外(投稿者本人の発言ではないため、プログラム側で自動的に除外)"
            results[i] = {
                "index": i + 1,
                "text": post["text"],
                "date": post["date"],
                "url": post["url"],
                "risk": "low",
                "category": "-",
                "details": [],
                "reason": rt_reason,
                "original_reason": rt_reason,
                "correction_notes": [],
                "correction_type": None,
            }
            done_count += 1
            window.write_event_value("-PROGRESS-", (done_count, total))
        else:
            llm_target_indices.append(i)

    if done_count:
        window.write_event_value("-LOG-", f"RT(リツイート)と判定された{done_count}件を評価対象から自動的に除外しました")

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_to_index = {
            executor.submit(llm_check, posts[i]["text"], config): i for i in llm_target_indices
        }
        for future in as_completed(future_to_index):
            i = future_to_index[future]
            try:
                l_result = future.result()
            except Exception as e:
                l_result = {"risk": "low", "matched_categories": [], "extracted_details": [], "reason": f"LLMエラー: {e}"}

            categories = l_result.get("matched_categories") or []
            details = l_result.get("extracted_details") or []
            results[i] = {
                "index": i + 1,
                "text": posts[i]["text"],
                "date": posts[i]["date"],
                "url": posts[i]["url"],
                "risk": l_result.get("risk", "low"),
                "category": "、".join(categories) if categories else "-",
                "details": details,
                "reason": l_result.get("reason", ""),
                "original_reason": l_result.get("original_reason", l_result.get("reason", "")),
                "correction_notes": l_result.get("correction_notes", []),
                "correction_type": l_result.get("correction_type"),
            }

            done_count += 1
            window.write_event_value("-PROGRESS-", (done_count, total))
            window.write_event_value(
                "-LOG-",
                f"[{done_count}/{total}] 投稿{i + 1} 判定完了 (リスク: {RISK_LABELS[results[i]['risk']]})",
            )

    window.write_event_value("-LOG-", "全投稿の結果を統合し、総合レポートを作成しています...")
    aggregate_report = llm_aggregate_profile(results, config)
    if aggregate_report:
        window.write_event_value(
            "-LOG-",
            f"総合レポート作成完了 (総合リスク: {RISK_LABELS[aggregate_report['overall_risk']]})",
        )
    else:
        window.write_event_value("-LOG-", "総合レポート: 対象となる投稿がなかったため作成をスキップしました")

    individual_dangerous = [r for r in results if r["risk"] in ("critical", "high")]
    aggregate_flags_risk = bool(
        aggregate_report and aggregate_report.get("overall_risk") in ("critical", "high")
    )

    if individual_dangerous or aggregate_flags_risk:
        ok, msg = parent_notifier.send_parent_notification(
            results,
            sender_email=config.get("parent_email"),
            parent_email=config.get("parent_email"),
            smtp_server=config.get("smtp_server"),
            smtp_port=config.get("smtp_port"),
            app_password=parent_password or None,
            aggregate_summary=aggregate_report,
        )
        notified_label = "送信済み" if ok else "送信失敗"
        for r in individual_dangerous:
            r["notified"] = notified_label
        if aggregate_flags_risk:
            for r in results:
                if r["risk"] == "medium":
                    r["notified"] = notified_label
        window.write_event_value("-LOG-", f"保護者への通知メール: {msg}")
    for r in results:
        if r.get("notified") is None:
            r["notified"] = "-"

    save_history_record(os.path.basename(json_path), results, aggregate_report)

    window.write_event_value("-DONE-", {"results": results, "aggregate": aggregate_report})


TABLE_HEADINGS = ["#", "カテゴリ", "投稿内容", "通知"]
TABLE_COL_WIDTHS = [4, 16, 70, 8]


def make_risk_tab(title: str, table_key: str, detail_key: str):
    """危険/高/中/低 タブの共通レイアウトを作る"""
    return sg.Tab(title, [
        [sg.Table(
            values=[],
            headings=TABLE_HEADINGS,
            key=table_key,
            auto_size_columns=False,
            col_widths=TABLE_COL_WIDTHS,
            justification="left",
            num_rows=18,
            font=FONT_NORMAL,
            header_font=FONT_HEADER,
            enable_events=True,
            expand_x=True,
            expand_y=True,
            row_height=28,
        )],
        [sg.Button("選択した投稿の詳細を見る", key=detail_key)],
    ])


def build_table_rows(results, risk: str):
    rows = []
    for r in results:
        if r["risk"] != risk:
            continue
        rows.append([r["index"], r["category"] or "-", r["text"], r["notified"]])
    return rows


def build_all_rows_sorted_by_risk(results):
    """
    全投稿を対象に、リスクの高い順(危険→高→中→低)に並べ替えた一覧を作る。
    投稿内容は省略せず全文を表示する。
    """
    sorted_results = sorted(
        results,
        key=lambda r: (RISK_ORDER[r["risk"]], r["index"]),
    )
    rows = []
    for r in sorted_results:
        rows.append([
            r["index"],
            RISK_LABELS[r["risk"]],
            r["category"] or "-",
            r["text"],
            r["notified"],
        ])
    return rows


def show_detail_popup(rows_list, selected_row_indices):
    """
    rows_list: そのテーブルに実際に表示されているresult辞書のリスト(表示順と一致させること)
    selected_row_indices: Tableから渡される選択行インデックスのリスト
    """
    if not selected_row_indices:
        sg.popup("行を選択してから押してください", title="未選択", font=FONT_NORMAL)
        return
    row_idx = selected_row_indices[0]
    if row_idx >= len(rows_list):
        return
    r = rows_list[row_idx]

    sg.popup_scrolled(
        f"投稿番号: {r['index']}\n"
        f"投稿日時: {r.get('date') or '不明'}\n"
        f"投稿URL: {r.get('url') or '不明'}\n"
        f"リスク: {RISK_LABELS[r['risk']]}\n"
        f"カテゴリ: {r['category'] or '-'}\n"
        f"通知: {r['notified']}\n\n"
        f"投稿内容:\n{r['text']}\n\n"
        f"判定理由:\n{r['reason']}",
        title=f"投稿{r['index']}の詳細",
        size=(80, 22),
        font=FONT_NORMAL,
    )


def main():
    sg.theme("DarkTeal9")
    config = load_config()

    settings_layout = [
        [sg.Text("保護者メールアドレス", size=(30, 1), font=FONT_NORMAL),
         sg.Input(config["parent_email"], key="-PARENT_EMAIL-", font=FONT_NORMAL)],
        [sg.Text("保護者メールのアプリパスワード", size=(30, 1), font=FONT_NORMAL),
         sg.Input("", key="-PARENT_PASS-", password_char="*", font=FONT_NORMAL)],
        [sg.Text("※ 危険な投稿を検知すると、上記のメールアドレスから自分自身宛に通知メールが送信されます。",
                 font=("Meiryo", 9), text_color="gray")],
        [sg.Text("Ollamaモデル名", size=(18, 1), font=FONT_NORMAL),
         sg.Input(config["ollama_model"], key="-MODEL-", font=FONT_NORMAL)],
        [sg.Text("並列処理数(LLM同時問い合わせ数)", size=(28, 1), font=FONT_NORMAL),
         sg.Spin([1, 2, 3, 4, 5, 6, 8], initial_value=config.get("max_workers", 3),
                 key="-MAX_WORKERS-", size=(5, 1), font=FONT_NORMAL)],
        [sg.Text("※ 並列数を上げるほど速くなりますが、CPU/メモリ負荷が上がります。\n"
                 "  ノートPCの場合は2〜4程度が目安です。", font=("Meiryo", 9), text_color="gray")],
        [sg.Button("設定を保存", key="-SAVE_CONFIG-")],
        [sg.HorizontalSeparator()],
        [sg.Text("パスワードの取り扱いについて", font=FONT_HEADER)],
        [sg.Text(
            "セキュリティのため、アプリパスワードは「設定を保存」を押しても\n"
            "設定ファイルには書き込まれません。上の入力欄はこのアプリを起動している間だけ有効で、\n"
            "次回起動時は再入力が必要です。\n\n"
            "毎回入力するのが面倒な場合は、子供のメールのパスワード欄を空欄のままにしておくと、\n"
            "代わりにOSの環境変数「PII_GMAIL_APP_PASSWORD」から読み込みます\n"
            "(どちらか一方が設定されていればOKです)。",
            font=("Meiryo", 10),
        )],
        [sg.Button("環境変数の設定状況を確認", key="-CHECK_PASSWORD-")],
    ]

    inspect_layout = [
        [sg.Text("Xの投稿データ(tweets.js または .json)を選択してください", font=FONT_NORMAL)],
        [sg.Input(key="-FILE-", font=FONT_NORMAL), sg.FileBrowse(
            "参照", file_types=(("X archive files", "*.js *.json"), ("All files", "*.*")),
            font=FONT_NORMAL,
        )],
        [sg.Button("検査開始", key="-RUN-", font=FONT_HEADER, button_color=("white", "#2E8B57")),
         sg.Button("ログをクリア", key="-CLEAR-", font=FONT_NORMAL)],
        [sg.ProgressBar(max_value=100, orientation="h", size=(50, 20), key="-PROGBAR-")],
        [sg.Text("待機中", key="-PROG_TEXT-", font=FONT_NORMAL, size=(60, 1))],
        [sg.HorizontalSeparator()],
        [sg.Text("サマリー", font=FONT_HEADER)],
        [
            sg.Text("総投稿数: -", key="-SUM_TOTAL-", font=FONT_NORMAL, size=(14, 1)),
            sg.Text("危険: -", key="-SUM_CRITICAL-", font=FONT_NORMAL, size=(10, 1), text_color="#A94442"),
            sg.Text("高: -", key="-SUM_HIGH-", font=FONT_NORMAL, size=(10, 1), text_color="#D9534F"),
            sg.Text("中: -", key="-SUM_MEDIUM-", font=FONT_NORMAL, size=(10, 1), text_color="#B8860B"),
            sg.Text("低: -", key="-SUM_LOW-", font=FONT_NORMAL, size=(10, 1)),
            sg.Text("通知件数: -", key="-SUM_NOTIFIED-", font=FONT_NORMAL, size=(14, 1)),
        ],
        [sg.HorizontalSeparator()],
        [sg.Text("全投稿一覧（リスクの高い順にソート）", font=FONT_HEADER)],
        [sg.Table(
            values=[],
            headings=["#", "リスク", "カテゴリ", "投稿内容(全文)", "通知"],
            key="-TABLE_ALL-",
            auto_size_columns=False,
            col_widths=[4, 8, 16, 60, 8],
            justification="left",
            num_rows=14,
            font=FONT_NORMAL,
            header_font=FONT_HEADER,
            enable_events=True,
            expand_x=True,
            expand_y=True,
            row_height=28,
        )],
        [sg.Button("選択した投稿の詳細を見る", key="-DETAIL_ALL-")],
    ]

    log_layout = [
        [sg.Multiline(
            size=(110, 30), key="-LOG-", autoscroll=True, disabled=True,
            font=FONT_LOG, expand_x=True, expand_y=True, background_color="#1E1E1E",
            text_color="#D4D4D4",
        )],
    ]

    report_layout = [
        [sg.Text("総合レポート", font=FONT_HEADER)],
        [sg.Text(
            "全投稿を横断的に分析し、組み合わせによって特定できてしまう情報をまとめます。\n"
            "検査を実行すると、ここに結果が表示されます。",
            font=FONT_NORMAL,
        )],
        [sg.Text("総合リスク判定: -", key="-REPORT_RISK-", font=FONT_HEADER)],
        [sg.Text("推定できてしまう情報", font=FONT_HEADER)],
        [sg.Multiline(
            "", key="-REPORT_PROFILE-", size=(100, 6), disabled=True,
            font=FONT_NORMAL, expand_x=True,
        )],
        [sg.Text("特にリスクを引き上げた組み合わせ", font=FONT_HEADER)],
        [sg.Multiline(
            "", key="-REPORT_COMBINATION-", size=(100, 4), disabled=True,
            font=FONT_NORMAL, expand_x=True,
        )],
    ]

    history_layout = [
        [sg.Text("実行履歴", font=FONT_HEADER)],
        [sg.Text(
            "過去に実行した検査結果の一覧です。行を選択して「この履歴を表示」を押すと、\n"
            "他のタブに当時の結果が復元されます(再検査は行われません)。",
            font=FONT_NORMAL,
        )],
        [sg.Button("この履歴を表示", key="-HISTORY_OPEN-", font=FONT_HEADER,
                    button_color=("white", "#2E8B57")),
         sg.Button("一覧を更新", key="-HISTORY_REFRESH-", font=FONT_NORMAL)],
        [sg.Table(
            values=[],
            headings=["実行日時", "ファイル", "総数", "危険", "高", "中", "低", "通知"],
            key="-TABLE_HISTORY-",
            auto_size_columns=False,
            col_widths=[18, 20, 6, 6, 6, 6, 6, 6],
            justification="left",
            num_rows=10,
            font=FONT_NORMAL,
            header_font=FONT_HEADER,
            enable_events=True,
            expand_x=True,
            expand_y=False,
            row_height=28,
        )],
    ]

    layout = [
        [sg.TabGroup([[
            sg.Tab("検査 / 概要", inspect_layout),
            sg.Tab("総合レポート", report_layout),
            make_risk_tab("危険", "-TABLE_CRITICAL-", "-DETAIL_CRITICAL-"),
            make_risk_tab("高", "-TABLE_HIGH-", "-DETAIL_HIGH-"),
            make_risk_tab("中", "-TABLE_MEDIUM-", "-DETAIL_MEDIUM-"),
            make_risk_tab("低", "-TABLE_LOW-", "-DETAIL_LOW-"),
            sg.Tab("履歴", history_layout),
            sg.Tab("処理ログ", log_layout),
            sg.Tab("設定", settings_layout),
        ]], expand_x=True, expand_y=True, font=FONT_NORMAL)],
        [sg.Button("終了", font=FONT_NORMAL)],
    ]

    window = sg.Window(
        "X投稿 個人情報検知アプリ", layout,
        finalize=True, resizable=True, size=(950, 700),
    )

    latest_results = []
    current_table_rows = {"critical": [], "high": [], "medium": [], "low": [], "all": []}
    is_running = False
    history_records = load_history_records()

    def refresh_history_table():
        rows = [
            [
                rec.get("timestamp", ""),
                rec.get("source_file", ""),
                rec.get("total", 0),
                rec.get("counts", {}).get("critical", 0),
                rec.get("counts", {}).get("high", 0),
                rec.get("counts", {}).get("medium", 0),
                rec.get("counts", {}).get("low", 0),
                rec.get("notified", 0),
            ]
            for rec in history_records[:MAX_HISTORY_DISPLAY]
        ]
        window["-TABLE_HISTORY-"].update(values=rows)

    refresh_history_table()

    def display_results(results, aggregate_report):
        """検査結果(または履歴から読み込んだ結果)を、サマリー・各タブ・総合レポートに反映する"""
        nonlocal latest_results
        latest_results = results

        total = len(results)
        critical_n = sum(1 for r in results if r["risk"] == "critical")
        high_n = sum(1 for r in results if r["risk"] == "high")
        medium_n = sum(1 for r in results if r["risk"] == "medium")
        low_n = sum(1 for r in results if r["risk"] == "low")
        notified_n = sum(1 for r in results if r.get("notified") == "送信済み")

        window["-PROGBAR-"].update(100, max=100)
        window["-PROG_TEXT-"].update(f"完了: 全{total}件処理しました")
        window["-SUM_TOTAL-"].update(f"総投稿数: {total}")
        window["-SUM_CRITICAL-"].update(f"危険: {critical_n}")
        window["-SUM_HIGH-"].update(f"高: {high_n}")
        window["-SUM_MEDIUM-"].update(f"中: {medium_n}")
        window["-SUM_LOW-"].update(f"低: {low_n}")
        window["-SUM_NOTIFIED-"].update(f"通知件数: {notified_n}")

        window["-TABLE_CRITICAL-"].update(values=build_table_rows(results, "critical"))
        window["-TABLE_HIGH-"].update(values=build_table_rows(results, "high"))
        window["-TABLE_MEDIUM-"].update(values=build_table_rows(results, "medium"))
        window["-TABLE_LOW-"].update(values=build_table_rows(results, "low"))
        window["-TABLE_ALL-"].update(values=build_all_rows_sorted_by_risk(results))

        current_table_rows["critical"] = [r for r in results if r["risk"] == "critical"]
        current_table_rows["high"] = [r for r in results if r["risk"] == "high"]
        current_table_rows["medium"] = [r for r in results if r["risk"] == "medium"]
        current_table_rows["low"] = [r for r in results if r["risk"] == "low"]
        current_table_rows["all"] = sorted(results, key=lambda r: (RISK_ORDER[r["risk"]], r["index"]))

        if aggregate_report:
            window["-REPORT_RISK-"].update(f"総合リスク判定: {RISK_LABELS[aggregate_report['overall_risk']]}")
            window["-REPORT_PROFILE-"].update(aggregate_report.get("inferred_profile", ""))
            window["-REPORT_COMBINATION-"].update(
                aggregate_report.get("key_combination", "") or "(特筆すべき組み合わせはありませんでした)"
            )
        else:
            window["-REPORT_RISK-"].update("総合リスク判定: 対象投稿なし")
            window["-REPORT_PROFILE-"].update("危険・高・中リスクと判定された投稿がなかったため、統合分析は行われませんでした。")
            window["-REPORT_COMBINATION-"].update("")

    def log(text):
        window["-LOG-"].update(text + "\n", append=True)

    while True:
        event, values = window.read()

        if event in (sg.WIN_CLOSED, "終了"):
            break

        elif event == "-CLEAR-":
            window["-LOG-"].update("")

        elif event == "-SAVE_CONFIG-":
            config["parent_email"] = values["-PARENT_EMAIL-"].strip()
            config["ollama_model"] = values["-MODEL-"].strip()
            config["max_workers"] = int(values["-MAX_WORKERS-"])
            save_config(config)
            sg.popup("設定を保存しました", title="完了", font=FONT_NORMAL)

        elif event == "-CHECK_PASSWORD-":
            if parent_notifier.is_password_configured():
                sg.popup(
                    "環境変数 PII_GMAIL_APP_PASSWORD が設定されています。\n"
                    "(値の内容はセキュリティのため表示しません)",
                    title="確認結果", font=FONT_NORMAL,
                )
            else:
                sg.popup(
                    "環境変数 PII_GMAIL_APP_PASSWORD が見つかりません。\n"
                    "設定タブの説明を参考に、OSの環境変数を設定してから\n"
                    "アプリを再起動してください。",
                    title="確認結果", font=FONT_NORMAL,
                )

        elif event == "-RUN-":
            if is_running:
                sg.popup("現在処理中です。完了までお待ちください。", font=FONT_NORMAL)
                continue

            json_path = values["-FILE-"]
            if not json_path or not os.path.exists(json_path):
                sg.popup_error("有効なファイルを選択してください", font=FONT_NORMAL)
                continue

            config["parent_email"] = values["-PARENT_EMAIL-"].strip()
            config["ollama_model"] = values["-MODEL-"].strip()
            config["max_workers"] = int(values["-MAX_WORKERS-"])
            parent_password = values["-PARENT_PASS-"]

            window["-LOG-"].update("")
            window["-PROGBAR-"].update(0, max=100)
            window["-PROG_TEXT-"].update("処理を開始します...")
            for k in ("-TABLE_CRITICAL-", "-TABLE_HIGH-", "-TABLE_MEDIUM-", "-TABLE_LOW-", "-TABLE_ALL-"):
                window[k].update(values=[])
            window["-SUM_TOTAL-"].update("総投稿数: -")
            window["-SUM_CRITICAL-"].update("危険: -")
            window["-SUM_HIGH-"].update("高: -")
            window["-SUM_MEDIUM-"].update("中: -")
            window["-SUM_LOW-"].update("低: -")
            window["-SUM_NOTIFIED-"].update("通知件数: -")
            window["-REPORT_RISK-"].update("総合リスク判定: -")
            window["-REPORT_PROFILE-"].update("")
            window["-REPORT_COMBINATION-"].update("")

            is_running = True
            window["-RUN-"].update(disabled=True)

            threading.Thread(
                target=run_pipeline_background,
                args=(json_path, config, window, parent_password),
                daemon=True,
            ).start()

        elif event == "-LOG-":
            log(values[event])

        elif event == "-PROGRESS-":
            done, total = values[event]
            pct = int(done / total * 100) if total else 0
            window["-PROGBAR-"].update(pct, max=100)
            window["-PROG_TEXT-"].update(f"処理中... {done}/{total}件 ({pct}%)")

        elif event == "-ERROR-":
            is_running = False
            window["-RUN-"].update(disabled=False)
            sg.popup_error(values[event], font=FONT_NORMAL)

        elif event == "-DONE-":
            is_running = False
            window["-RUN-"].update(disabled=False)
            payload = values[event]
            display_results(payload["results"], payload["aggregate"])

            total = len(payload["results"])
            critical_n = sum(1 for r in payload["results"] if r["risk"] == "critical")
            high_n = sum(1 for r in payload["results"] if r["risk"] == "high")
            medium_n = sum(1 for r in payload["results"] if r["risk"] == "medium")
            low_n = sum(1 for r in payload["results"] if r["risk"] == "low")
            notified_n = sum(1 for r in payload["results"] if r.get("notified") == "送信済み")
            log(f"\n完了: 全{total}件中 危険{critical_n}件 / 高{high_n}件 / 中{medium_n}件 / 低{low_n}件 / 通知{notified_n}件")

            history_records = load_history_records()
            refresh_history_table()

        elif event == "-DETAIL_CRITICAL-":
            show_detail_popup(current_table_rows["critical"], values.get("-TABLE_CRITICAL-", []))
        elif event == "-DETAIL_HIGH-":
            show_detail_popup(current_table_rows["high"], values.get("-TABLE_HIGH-", []))
        elif event == "-DETAIL_MEDIUM-":
            show_detail_popup(current_table_rows["medium"], values.get("-TABLE_MEDIUM-", []))
        elif event == "-DETAIL_LOW-":
            show_detail_popup(current_table_rows["low"], values.get("-TABLE_LOW-", []))
        elif event == "-DETAIL_ALL-":
            show_detail_popup(current_table_rows["all"], values.get("-TABLE_ALL-", []))

        elif event == "-HISTORY_REFRESH-":
            history_records = load_history_records()
            refresh_history_table()

        elif event == "-HISTORY_OPEN-":
            selected = values.get("-TABLE_HISTORY-", [])
            if not selected:
                sg.popup("履歴の行を選択してから押してください", title="未選択", font=FONT_NORMAL)
                continue
            row_idx = selected[0]
            if row_idx >= len(history_records[:MAX_HISTORY_DISPLAY]):
                continue
            rec = history_records[row_idx]
            display_results(rec["results"], rec.get("aggregate"))
            sg.popup(
                f"{rec.get('timestamp')} の実行結果を表示しました。\n"
                "「検査/概要」「危険」「高」「中」「低」「総合レポート」タブでご確認いただけます。",
                title="履歴を表示しました", font=FONT_NORMAL,
            )

    window.close()


if __name__ == "__main__":
    main()
