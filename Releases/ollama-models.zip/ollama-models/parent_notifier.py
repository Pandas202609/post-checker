# -*- coding: utf-8 -*-
"""
============================================================
保護者メール通知モジュール
parent_notifier.py
============================================================

【このプログラムでできること】

個人情報検知アプリ(pii_detector_app.py)で検出された危険な投稿について、

・危険度
・検出カテゴリ
・危険と判断した理由

を1通のメールにまとめて保護者へ通知します。
(投稿1件ごとにメールを送るのではなく、検査1回につき1通にまとめます)

現在は Gmail を使ってメールを送信します。


【重要】

Googleアカウントの通常のパスワードは使用しません。

Gmailの「アプリパスワード」を環境変数に保存し、
このプログラムはそこからパスワードを読み込みます。

そのため、

・Googleの通常パスワード
・Gmailのアプリパスワード

をこのPythonファイルや設定ファイルに直接書かないでください。


【pii_detector_app.py から使う場合】

GUIの「設定」タブで入力した送信元/宛先メールアドレスを
send_parent_notification() の引数として渡すことで、
このファイル内の SENDER_EMAIL / PARENT_EMAIL を書き換えなくても動作します。

このファイル単体でテストしたい場合は、下の
SENDER_EMAIL / PARENT_EMAIL に直接入力してから
"python parent_notifier.py" を実行してください。
"""

import os
import smtplib
from email.mime.text import MIMEText
from email.header import Header


# ============================================================
# メールアドレス設定(このファイル単体でテストする場合に使用)
# ============================================================

# // 使い方 //
#
# pii_detector_app.py から呼び出す場合は、
# GUIの「設定」タブで入力した値が優先されるため、
# ここは空のままで問題ありません。
#
# このファイル単体でテストしたい場合のみ、
# "" の中にメールアドレスを入力してください。
#
# 【重要】
# Gmailのパスワードやアプリパスワードは
# ここには入力しません。
# ============================================================

SENDER_EMAIL = ""
PARENT_EMAIL = ""


# ============================================================
# Gmail SMTP設定
# ============================================================

# // 基本的には変更しなくてOKです //
#
# 現在はGmailを使用する設定です。
#
# 後からOutlookなど別のメールサービスに変更する場合は、
# この部分、またはsend_parent_notification()の引数を変更することで対応できます。
# ============================================================

SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587


# ============================================================
# 環境変数の名前
# ============================================================

# // 使い方 //
#
# Gmailのアプリパスワードは、
#
# PII_GMAIL_APP_PASSWORD
#
# という名前の環境変数から取得します。
#
# Pythonファイルにはパスワードを保存しないため、
# GitHubなどにコードをアップロードしても
# パスワードが一緒に公開される危険を減らせます。
#
# 【Windowsでの設定方法】
#   1. 「システム環境変数の編集」を開く
#   2. 「環境変数」ボタン → 「新規」
#   3. 変数名: PII_GMAIL_APP_PASSWORD
#      変数値: Gmailのアプリパスワード(16桁)
#   4. 設定後、アプリを再起動しないと反映されない点に注意
#
# 【Mac/Linuxでの設定方法】
#   ターミナルで以下を実行(その場限り)
#     export PII_GMAIL_APP_PASSWORD="アプリパスワード"
#   恒久的に設定したい場合は ~/.zshrc や ~/.bashrc に上記を追記
# ============================================================

PASSWORD_ENV_NAME = "PII_GMAIL_APP_PASSWORD"


def is_password_configured() -> bool:
    """環境変数にアプリパスワードが設定されているかどうかだけを確認する(値自体は返さない)"""
    return bool(os.environ.get(PASSWORD_ENV_NAME))


# ============================================================
# 通知対象を抽出
# ============================================================

def get_dangerous_results(results, include_medium=False):
    """
    // この関数について //

    個人情報検知システムの判定結果から、

        critical → 危険
        high     → 高

    のものを取り出します。

    include_medium=True の場合は、単体では medium(中) 判定でも
    (統合分析によって全体としては危険/高相当と判断された場合を想定して)
    合わせて取り出します。
    """

    dangerous_results = []

    for result in results:

        risk = result.get("risk", "low")

        if risk in ("critical", "high"):
            dangerous_results.append(result)
        elif include_medium and risk == "medium":
            dangerous_results.append(result)

    return dangerous_results


# ============================================================
# 危険度を日本語に変換
# ============================================================

def convert_risk_label(risk):
    """
    // この関数について //

    プログラム内部では

        critical
        high
        medium
        low

    となっている危険度を、

        危険
        高
        中
        低

    に変換します。
    """

    labels = {
        "critical": "危険",
        "high": "高",
        "medium": "中",
        "low": "低"
    }

    return labels.get(risk, "不明")


# ============================================================
# メール本文を作成
# ============================================================

def create_email_body(results, aggregate_summary=None, include_medium=False):
    """
    // この関数について //

    検出された危険な投稿をまとめて、
    保護者へ送るメール本文を作ります。

    aggregate_summary を渡した場合は、
    「全投稿を横断して統合分析した結果(総合レポート)」を
    メール冒頭に追加します。

    現在メールに表示する個別投稿の情報は、

        ・危険度
        ・検出カテゴリ
        ・危険と判断した理由
        ・投稿URL(取得できている場合)

    の4つです。

    投稿本文そのものは現在送信しません。
    (投稿本文までメールに残すと、メール自体が個人情報の塊になってしまうため)
    投稿URLを付けることで、保護者が実際の投稿(画像や前後の文脈含む)を
    直接確認できるようにしています。
    """

    dangerous_results = get_dangerous_results(results, include_medium=include_medium)

    body = ""

    # --------------------------------------------
    # 総合レポート(統合分析結果)をメール冒頭に追加
    # --------------------------------------------
    if aggregate_summary:

        overall_label = convert_risk_label(
            aggregate_summary.get("overall_risk", "medium")
        )

        body += "========================================\n"
        body += " 総合レポート(全投稿を横断的に分析した結果)\n"
        body += "========================================\n\n"

        body += f"総合リスク判定：{overall_label}\n\n"

        body += "推定できてしまう情報：\n"
        body += f"{aggregate_summary.get('inferred_profile') or '(情報なし)'}\n\n"

        key_combination = aggregate_summary.get("key_combination")
        if key_combination:
            body += "特にリスクを引き上げた組み合わせ：\n"
            body += f"{key_combination}\n\n"

        body += "========================================\n\n"

    body += "個人情報検知システムによる検査結果です。\n\n"

    body += (
        f"{len(dangerous_results)}件の"
        "危険な投稿が検出されました。\n\n"
    )

    body += "内容をご確認ください。\n\n"

    body += "========================================\n\n"

    for number, result in enumerate(dangerous_results, start=1):

        risk = convert_risk_label(
            result.get("risk", "none")
        )

        category = result.get(
            "category",
            "不明"
        )

        reason = result.get(
            "reason",
            "理由なし"
        )

        url = result.get("url", "")

        body += f"【検出結果 {number}】\n\n"

        body += f"危険度：{risk}\n"

        body += f"検出カテゴリ：{category}\n"

        body += "危険と判断した理由：\n"
        body += f"{reason}\n\n"

        if url:
            body += f"投稿URL：{url}\n\n"

        body += "----------------------------------------\n\n"

    body += "以上の内容をご確認ください。\n\n"

    body += (
        "※このメールは個人情報検知システムによって"
        "自動送信されています。\n"
    )

    return body


# ============================================================
# 保護者へメールを送信
# ============================================================

def send_parent_notification(
    results,
    sender_email=None,
    parent_email=None,
    smtp_server=None,
    smtp_port=None,
    app_password=None,
    aggregate_summary=None,
):
    """
    // この関数について //

    この関数を呼び出すと、

    1. 危険・高リスクの結果を抽出(統合分析で高リスクとなった場合はmediumも含む)
    2. 1通のメール本文を作成(総合レポートがあれば冒頭に追加)
    3. Gmailへ接続
    4. 保護者へメール送信

    までを自動で行います。


    // 引数について //

    sender_email / parent_email / smtp_server / smtp_port を指定した場合は
    そちらが優先されます(pii_detector_app.pyのGUI設定から渡される想定)。
    指定しなかった場合は、このファイル上部の
    SENDER_EMAIL / PARENT_EMAIL / SMTP_SERVER / SMTP_PORT が使われます。

    app_password を指定した場合は、そちらが優先されます
    (pii_detector_app.pyのGUIでパスワードを直接入力した場合を想定)。
    指定しなかった場合(None)は、環境変数 PII_GMAIL_APP_PASSWORD から読み込みます。

    aggregate_summary は、全投稿を横断した統合分析の結果(dict)です。
    {"overall_risk": "critical/high/medium/low", "inferred_profile": "...", "key_combination": "..."}
    のような形を想定しています。overall_riskがcritical/highの場合は、
    単体ではmedium判定の投稿もメール本文に含めます
    (組み合わせによってリスクが引き上がったと判断されたため)。


    // 戻り値 //

    成功した場合

        True, "通知メールを送信しました"

    失敗した場合

        False, "エラー内容"

    が返されます。
    """

    # 引数が指定されなければ、このファイル上部の設定値を使う
    sender_email = sender_email or SENDER_EMAIL
    parent_email = parent_email or PARENT_EMAIL
    smtp_server = smtp_server or SMTP_SERVER
    smtp_port = smtp_port or SMTP_PORT

    # --------------------------------------------
    # 送信対象を決定
    # --------------------------------------------

    aggregate_flags_risk = bool(
        aggregate_summary and aggregate_summary.get("overall_risk") in ("critical", "high")
    )

    dangerous_results = get_dangerous_results(results, include_medium=aggregate_flags_risk)

    # 個別に危険/高な投稿がなく、統合分析でも高リスクと判定されなければ送信しない
    if not dangerous_results and not aggregate_flags_risk:

        return (
            False,
            "危険・高リスクの投稿がなく、統合分析でも高リスクと判定されなかったため、"
            "メールは送信しませんでした。"
        )

    # --------------------------------------------
    # メールアドレスが設定されているか確認
    # --------------------------------------------

    if not sender_email:

        return (
            False,
            "送信元メールアドレスが設定されていません。"
        )

    if not parent_email:

        return (
            False,
            "保護者のメールアドレスが設定されていません。"
        )

    # --------------------------------------------
    # Gmailアプリパスワードを取得
    # 優先順位: 引数で渡されたもの(GUI入力) > 環境変数
    # --------------------------------------------

    if not app_password:
        app_password = os.environ.get(PASSWORD_ENV_NAME)

    if not app_password:

        return (
            False,
            "アプリパスワードが未入力です。"
            "設定タブでパスワードを入力するか、"
            f"環境変数 {PASSWORD_ENV_NAME} を設定してください。"
        )

    # --------------------------------------------
    # メール本文を作成
    # --------------------------------------------

    body = create_email_body(results, aggregate_summary=aggregate_summary, include_medium=aggregate_flags_risk)

    # --------------------------------------------
    # メールを作成
    # --------------------------------------------

    subject = "【個人情報検知】危険な投稿が検出されました"

    message = MIMEText(
        body,
        "plain",
        "utf-8"
    )

    message["Subject"] = Header(
        subject,
        "utf-8"
    )

    message["From"] = sender_email
    message["To"] = parent_email

    # --------------------------------------------
    # Gmailへ接続して送信
    # --------------------------------------------

    try:

        with smtplib.SMTP(
            smtp_server,
            smtp_port,
            timeout=30
        ) as server:

            # Gmailとの通信を暗号化
            server.starttls()

            # Gmailへログイン
            server.login(
                sender_email,
                app_password
            )

            # メール送信
            server.sendmail(
                sender_email,
                [parent_email],
                message.as_string()
            )

        return (
            True,
            "保護者へ通知メールを送信しました。"
        )

    except smtplib.SMTPAuthenticationError:

        return (
            False,
            "Gmailの認証に失敗しました。"
            "メールアドレスまたは"
            "アプリパスワードを確認してください。"
        )

    except Exception as error:

        return (
            False,
            f"メール送信中にエラーが発生しました: {error}"
        )


# ============================================================
# 単体テスト
# ============================================================

def test_notification():
    """
    // このテストについて //

    parent_notifier.pyだけで
    メール送信を確認するためのテストです。

    メインの個人情報検知アプリを起動しなくても
    テストできます。

    下にある架空の検出結果をメールで送ります。
    このファイル上部の SENDER_EMAIL / PARENT_EMAIL に
    あらかじめメールアドレスを入力しておいてください。
    """

    print("========================================")
    print(" 保護者通知システム テスト")
    print("========================================")
    print()

    # --------------------------------------------
    # テスト用の架空データ
    # --------------------------------------------

    test_results = [

        {
            "risk": "critical",
            "category": "本人特定性、所属・社会的立場",
            "reason": (
                "呼び名と学校名が同時に判明しており、"
                "本人特定につながる恐れがあります。"
            ),
            "url": "https://x.com/i/web/status/1234567890123456789",
        },

        {
            "risk": "high",
            "category": "所属・社会的立場、行動パターン",
            "reason": (
                "所属先に加え、通学時間帯の"
                "行動パターンが判明しています。"
            ),
            "url": "https://x.com/i/web/status/9876543210987654321",
        },

        {
            "risk": "medium",
            "category": "生活拠点・行動圏",
            "reason": (
                "都道府県レベルの広域住所のみが"
                "判明しています。"
            ),
            "url": "https://x.com/i/web/status/1111122222333334444",
        },

        {
            "risk": "low",
            "category": "-",
            "reason": "個人情報につながる手がかりは検出されませんでした。",
            "url": "",
        }

    ]

    print("テストメールを送信します...")
    print()

    success, message = send_parent_notification(
        test_results
    )

    if success:

        print("【送信成功】")
        print(message)

    else:

        print("【送信失敗】")
        print(message)


# ============================================================
# このファイルを直接起動した場合
# ============================================================

# // 使い方 //
#
# ターミナル(PowerShell等)で
#
#     python parent_notifier.py
#
# と入力すると、
# 上の test_notification() が実行されます。
#
# 他のPythonファイルから
#
#     import parent_notifier
#
# と読み込んだ場合は、
# テストメールは勝手に送信されません。
# ============================================================

if __name__ == "__main__":

    test_notification()
